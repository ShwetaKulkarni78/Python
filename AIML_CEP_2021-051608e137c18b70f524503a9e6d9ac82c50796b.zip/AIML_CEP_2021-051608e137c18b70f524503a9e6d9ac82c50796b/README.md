# AIML_CEP_2021
Repo for AIML CEP 2021
This repo contains resources for AIML course offered during Autumn 2021.
